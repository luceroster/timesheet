/** @odoo-module */

import { CalendarRenderer } from '@web/views/calendar/calendar_renderer';

export class RockerCalendarRenderer extends CalendarRenderer {
    setup() {
        super.setup();
    }
}

